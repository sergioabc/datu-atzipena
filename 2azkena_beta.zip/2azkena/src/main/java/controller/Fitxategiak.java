package controller;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class Fitxategiak {

	static Document xmlDOM;

	public static void main(String[] args) {
		String csvFile = "estaciones.csv";
		String xmlFile = "estaciones.xml";
		String jsonFile = "estaciones.json";

		irakurricsv(csvFile);
		// irakurrixml(xmlFile);
		// irakurrijson(jsonFile);

	}

	public static void irakurricsv(String csvFile) {
		try (BufferedReader inputStream = new BufferedReader(new FileReader(csvFile))) {
			String l;
			String[] lerroa;
			while ((l = inputStream.readLine()) != null) {
				lerroa = l.split(",");

				System.out.println("Name: " + lerroa[0] + ", Province: " + lerroa[1] + ", Town: " + lerroa[2]
						+ ", Address: " + lerroa[3] + ", CoorX: " + lerroa[4] + ", CoorY: " + lerroa[5] + ", Latitude: "
						+ lerroa[6] + ", Longitude: " + lerroa[7]);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Error: " + e);
		} catch (IOException ex) {
			Logger.getLogger(Fitxategiak.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public static void irakurrixml(String xmlFile) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(xmlFile);

			NodeList stationList = doc.getElementsByTagName("station");

			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

			for (int i = 0; i < stationList.getLength(); i++) {
				Node n = stationList.item(i);
				System.out.println("Node name: " + n.getNodeName() + " " + (i + 1));
				if (n.getNodeType() == Node.ELEMENT_NODE) {
					Element name = (Element) n;
					System.out.println("Station id: " + name.getAttribute("id"));
					System.out.println("Name: " + name.getElementsByTagName("Name").item(0).getTextContent());
					System.out.println("Province: " + name.getElementsByTagName("Province").item(0).getTextContent());
					System.out.println("Town: " + name.getElementsByTagName("Town").item(0).getTextContent());
					System.out.println("Address: " + name.getElementsByTagName("Address").item(0).getTextContent());
					System.out.println("CoordenatesXETRS89: "
							+ name.getElementsByTagName("CoordenatesXETRS89").item(0).getTextContent());
					System.out.println("CoordenatesYETRS89: "
							+ name.getElementsByTagName("CoordenatesYETRS89").item(0).getTextContent());
					System.out.println("Latitude: " + name.getElementsByTagName("Latitude").item(0).getTextContent());
					System.out.println("Longitude: " + name.getElementsByTagName("Longitude").item(0).getTextContent());
					System.out.println("-------------------------------------------------------------");

				}
			}

		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}

	public static void irakurrijson(String jsonFile) {
		JSONParser jsonP = new JSONParser();

		try (FileReader reader = new FileReader("estaciones.json")) {
			Object obj = jsonP.parse(reader);

			JSONArray stList = (JSONArray) obj;
			// System.out.println(stList);
			for (int i = 0; i < stList.size(); i++) {
				// System.out.println(stList.get(i));
				JSONObject stobj = (JSONObject) stList.get(i);

				String name = (String) stobj.get("Name");
				String province = (String) stobj.get("Province");
				String town = (String) stobj.get("Town");
				String address = (String) stobj.get("Address");
				String coorX = (String) stobj.get("CoordenatesXETRS89");
				String coorY = (String) stobj.get("CoordenatesYETRS89");
				String latitude = (String) stobj.get("Latitude");
				String longitude = (String) stobj.get("Longitude");

				System.out.println("Name: " + name + " | Province: " + province + " | Town: " + town + " | Address: "
						+ address + " | CoordenatesX: " + coorX + " | CoordenatesY: " + coorY + " | Latitude: "
						+ latitude + " | Longitude: " + longitude);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
