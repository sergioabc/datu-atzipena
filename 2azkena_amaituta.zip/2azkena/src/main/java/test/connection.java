package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import global.Global;

import model.Station;

public class connection {
	static Connection co = null;
	String db = "estaciones";
	String url = "jdbc:mariadb://localhost:3306/" + db;
	String user = "root";
	String pass = "admin";

	public static void main(String[] args) {
		connection c = new connection();
		c.konektatu();
	}

	public Connection conectar() {
		try {
			Class.forName("com.mariadb.jdbc.Driver");
			co = (Connection)DriverManager.getConnection(url, user, pass);
			System.out.println("KONEXIOA ONDO EGINDA");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return co;
	}

	public void desconectar() {
		try {
			co.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Ezin da konexioa itxi...");
		}
	}
	 public static Connection konektatu() {
	        Connection konexioa = null;
	        String server = "localhost";
	        String db = "estaciones";
	        String urla = "jdbc:mysql://" + server + "/" + db;
	        //String urla = "";
	        String user = "root";
	        String pass = "admin";
	        try {
	            urla = "jdbc:mysql://" + Global.ZERBITZARIA + "/" + Global.DATUBASEA;
	            co = DriverManager.getConnection(urla, Global.getErabiltzailea(), Global.getPasahitza());
	            System.out.println(Global.DATUBASEA + " datu-basera konektatuta");
	        } catch (SQLException e) {
	            if (e.getErrorCode() == 1049) {
	                System.out.println("Datu base ezezaguna");
	            } else {
	                System.out.println(e.getMessage());
	            }
	        }
	        return co;
	    }
}
