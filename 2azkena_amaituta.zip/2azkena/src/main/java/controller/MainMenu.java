package controller;

import java.util.Scanner;

import global.Global;

public class MainMenu {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int aukera = 1, aukera2 = 1;
		try {
			while (aukera > 0) {
				aukera2 = 1;
				System.out.println("----------------------------------------");
				System.out.println("|          2.Azkena: Sergio            |");
				System.out.println("|                                      |");
				System.out.println("|               0.Irten                |");
				System.out.println("|             1.Fitxategiak            |");
				System.out.println("|              2.MariaDB               |");
				System.out.println("|              3.MongoDB               |");
				System.out.println("|                                      |");
				System.out.println("----------------------------------------");

				System.out.println("Sartu aukera bat: ");
				aukera = sc.nextInt();
				if (aukera == 0) {
					System.exit(0);
				} else if (aukera == 1) {
					while (aukera2 > 0) {
						System.out.println("----------------------------------------");
						System.out.println("|        Fitxategien CRUD menua:       |");
						System.out.println("|                                      |");
						System.out.println("|               0.Irten                |");
						System.out.println("|                                      |");
						System.out.println("|            1.Irakurri CSV            |");
						System.out.println("|            2.Idatzi CSV              |");
						System.out.println("|            3.Eguneratu CSV           |");
						System.out.println("|            4.Ezabatu CSV             |");
						System.out.println("|                                      |");
						System.out.println("|            5.Irakurri XML            |");
						System.out.println("|            6.Idatzi XML              |");
						System.out.println("|            7.Eguneratu XML           |");
						System.out.println("|            8.Ezabatu XML             |");
						System.out.println("|                                      |");
						System.out.println("|            9.Irakurri JSON           |");
						System.out.println("|            10.Idatzi JSON            |");
						System.out.println("|            11.Eguneratu JSON         |");
						System.out.println("|            12.Ezabatu JSON           |");
						System.out.println("----------------------------------------");
						System.out.println("Aukeratu bat: ");
						aukera2 = sc.nextInt();
						switch (aukera2) {
						case 0:
							break;
						case 1:
							model.Fitxategiak.irakurricsv(Global.csvFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 2:
							model.Fitxategiak.idatzicsv(Global.csvFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 3:
							model.Fitxategiak.eguneratucsv(Global.csvFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 4:
							model.Fitxategiak.ezabatucsv(Global.csvFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 5:
							model.Fitxategiak.irakurrixml(Global.xmlFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 6:
							model.Fitxategiak.idatzixml(Global.xmlFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 7:
							model.Fitxategiak.eguneratuxml(Global.xmlFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 8:
							model.Fitxategiak.ezabatuxml(Global.xmlFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 9:
							model.Fitxategiak.irakurrijson(Global.jsonFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 10:
							model.Fitxategiak.idatzijson(Global.jsonFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 11:
							model.Fitxategiak.eguneratujson(Global.jsonFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 12:
							model.Fitxategiak.ezabatujson(Global.jsonFile);
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						}
					}
				} else if (aukera == 2) {
					while (aukera2 > 0) {
						System.out.println("----------------------------------------");
						System.out.println("|       SQL (MariaDB) CRUD menua       |");
						System.out.println("|                                      |");
						System.out.println("|             0.Irten                  |");
						System.out.println("|                                      |");
						System.out.println("|             1.Irakurri               |");
						System.out.println("|             2.Idatzi                 |");
						System.out.println("|             3.Eguneratu              |");
						System.out.println("|             4.Ezabatu                |");
						System.out.println("|             5.Probintziako geltokiak:|");
						System.out.println("|                                      |");
						System.out.println("----------------------------------------");
						System.out.println("Aukeratu bat: ");
						aukera2 = sc.nextInt();
						switch (aukera2) {
						case 0:
							break;
						case 1:
							model.MariaDBEragiketak.read();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 2:
							model.MariaDBEragiketak.create();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 3:
							model.MariaDBEragiketak.update();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 4:
							model.MariaDBEragiketak.delete();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 5:
							model.MariaDBEragiketak.probintziak();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						}
					}
				} else if (aukera == 3) {
					while (aukera2 > 0) {
						System.out.println("----------------------------------------");
						System.out.println("|      NO-SQL (MongoDB) CRUD menua     |");
						System.out.println("|                                      |");
						System.out.println("|             0.Irten                  |");
						System.out.println("|                                      |");
						System.out.println("|          1.Irakurri guztiak:         |");
						System.out.println("|          2.Idatzi geltoki bat:       |");
						System.out.println("|          3.Eguneratu geltoki bat:    |");
						System.out.println("|          4.Ezabatu geltoki bat       |");
						System.out.println("|          5.Probintziako geltokiak:   |");
						System.out.println("|                                      |");
						System.out.println("----------------------------------------");
						System.out.println("Aukeratu bat: ");
						aukera2 = sc.nextInt();
						switch (aukera2) {
						case 0: 
							break;
						case 1:
							model.MongoEragiketak.readAll();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 2:
							model.MongoEragiketak.createStation();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 3:
							model.MongoEragiketak.updateStation();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 4:
							model.MongoEragiketak.deleteStation();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						case 5:
							model.MongoEragiketak.readProvince();
							Thread.sleep(1000);
							System.out.println("\n");
							break;
						}
					}
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
