package model;

import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import java.util.Scanner;

import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.all;

import com.mongodb.MongoClientSettings;
import com.mongodb.MongoCommandException;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class MongoEragiketak {

	static CodecRegistry pojoCodecRegistry = fromRegistries(MongoClientSettings.getDefaultCodecRegistry(),
			fromProviders(PojoCodecProvider.builder().automatic(true).build()));
	static MongoClientSettings settings = MongoClientSettings.builder().codecRegistry(pojoCodecRegistry).build();
	static MongoClient mongoClient = MongoClients.create(settings);
	static MongoDatabase database = mongoClient.getDatabase("stations");
	static MongoCollection<Station> collection = database.getCollection("stations", Station.class);

	public static void main(String[] args) {
		// readAll();
		// createStation();
		// deleteStation();
		// updateStation();
		readProvince();
	}

	public static void readAll() {

		try (MongoCursor<Station> cur = collection.find().iterator()) {
			int count = 0;
			while (cur.hasNext()) {
				var station = cur.next();
				System.out.println("Name: " + station.getName() + " | Province: " + station.getProvince() + " | Town:"
						+ station.getTown() + " | Address: " + station.getAddress() + " | CoordenatesX: "
						+ station.getCoordenatesXETRS89() + " | CoordenatesY: " + station.getCoordenatesYETRS89()
						+ " | Latitude: " + station.getLatitude() + " | Longitude: " + station.getLongitude());
				count++;
			}
			System.out.println("Geltoki kopurua: " + count);
		}

	}

	public static void readProvince() {

		System.out.println("Sartu probintzia bat (Araba, Gipuzkoa, Bizkaia): ");
		Scanner sc = new Scanner(System.in);
		String prov = sc.nextLine();

		try (MongoCursor<Station> cur = collection.find(all("Province", prov)).iterator()) {
			while (cur.hasNext()) {
				var station = cur.next();
				if (station.getProvince().toString().contains(prov)) {
					System.out.println("Name: " + station.getName() + " | Province: " + station.getProvince()
							+ " | Town:" + station.getTown() + " | Address: " + station.getAddress()
							+ " | CoordenatesX: " + station.getCoordenatesXETRS89() + " | CoordenatesY: "
							+ station.getCoordenatesYETRS89() + " | Latitude: " + station.getLatitude()
							+ " | Longitude: " + station.getLongitude());
				}
			}
		}
	}

	public static void createStation() {
		Scanner sc = new Scanner(System.in);
		try {
			Station st = new Station();
			System.out.println("Ezarri geltokiaren izena (Maiuskuletan): ");
			st.setName(sc.nextLine());
			System.out.println("Ezarri geltokiaren probintzia: ");
			st.setProvince(sc.nextLine());
			System.out.println("Ezarri geltokiaren herria: ");
			st.setTown(sc.nextLine());
			System.out.println("Ezarri geltokiaren helbidea: ");
			st.setAddress(sc.nextLine());
			System.out.println("Ezarri geltokiaren X koordenadak (Adb: 54263.4223): ");
			st.setCoordenatesXETRS89(sc.nextLine());
			System.out.println("Ezarri geltokiaren Y koordenadak (Adb: 4539.792): ");
			st.setCoordenatesYETRS89(sc.nextLine());
			System.out.println("Ezarri geltokiaren latitudea (Adb: 39.54931687): ");
			st.setLatitude(sc.nextLine());
			System.out.println("Ezarri geltokiaren luzeera (Adb: -1.960650618338729):  ");
			st.setLongitude(sc.nextLine());

			collection.insertOne(st);

		} catch (MongoWriteException e) {
			System.out.println("Thit book already exists");
		}

		System.out.println("ONDO GEHITUTA!!! ");

	}

	public static void deleteStation() {
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Sartu geltokiaren izena: ");
			String oldName = sc.nextLine();

			collection.deleteOne(Filters.eq("Name", oldName));
		} catch (MongoCommandException e) {
			System.out.println("The book you tried to delete does not exist");
		}
		System.out.println("ONDO EZABATUTA!!! ");
	}

	public static void updateStation() {
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Sartu eguneratu nahi duzun geltokiaren izena: ");
			String oldName = sc.nextLine();

			Station st = new Station();

			System.out.println("Ezarri geltokiaren izena (Maiuskuletan): ");
			st.setName(sc.nextLine());
			System.out.println("Ezarri geltokiaren probintzia: ");
			st.setProvince(sc.nextLine());
			System.out.println("Ezarri geltokiaren herria: ");
			st.setTown(sc.nextLine());
			System.out.println("Ezarri geltokiaren helbidea: ");
			st.setAddress(sc.nextLine());
			System.out.println("Ezarri geltokiaren X koordenadak (Adb: 54263.4223): ");
			st.setCoordenatesXETRS89(sc.nextLine());
			System.out.println("Ezarri geltokiaren Y koordenadak (Adb: 4539.792): ");
			st.setCoordenatesYETRS89(sc.nextLine());
			System.out.println("Ezarri geltokiaren latitudea (Adb: 39.54931687): ");
			st.setLatitude(sc.nextLine());
			System.out.println("Ezarri geltokiaren luzeera (Adb: -1.960650618338729):  ");
			st.setLongitude(sc.nextLine());

			collection.replaceOne(eq("Name", oldName), st);
		} catch (MongoCommandException e) {
			System.out.println("The book you tried to delete does not exist");
		}
		System.out.println("ONDO EGUNERATUTA!!! ");
	}
}
