package model;

import test.connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import global.Global;

public class MariaDBEragiketak {

	public static void main(String[] args) {

		// read();
		// create();
		// delete();
		// update();
		probintziak();
	}

	public static ArrayList<Station> read() {

		connection c = new connection();
		// c.konektatu();
		ArrayList<Station> list = new ArrayList<Station>();
		try {
			String sql = "SELECT * FROM station";
			PreparedStatement ps = c.konektatu().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Station s = new Station();
				s.setName(rs.getString("Name"));
				s.setProvince(rs.getString("Province"));
				s.setTown(rs.getString("Town"));
				s.setAddress(rs.getString("Address"));
				s.setCoordenatesXETRS89(rs.getString("CoordenatesXETRS89"));
				s.setCoordenatesYETRS89(rs.getString("CoordenatesYETRS89"));
				s.setLatitude(rs.getString("Latitude"));
				s.setLongitude(rs.getString("Latitude"));
				list.add(s);
			}
			ps.close();
			ps = null;
			c.desconectar();

			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i));
			}
		}

		catch (SQLException ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public static void create() {
		connection c = new connection();
		String name, prov, town, addr, coorX, coorY, lati, longi;
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Ezarri geltokiaren izena (Maiuskuletan): ");
			name = sc.nextLine();
			System.out.println("Ezarri geltokiaren probintzia: ");
			prov = sc.nextLine();
			System.out.println("Ezarri geltokiaren herria: ");
			town = sc.nextLine();
			System.out.println("Ezarri geltokiaren helbidea: ");
			addr = sc.nextLine();
			System.out.println("Ezarri geltokiaren X koordenadak (Adb: 54263.4223): ");
			coorX = sc.nextLine();
			System.out.println("Ezarri geltokiaren Y koordenadak (Adb: 4539.792): ");
			coorY = sc.nextLine();
			System.out.println("Ezarri geltokiaren latitudea (Adb: 39.54931687): ");
			lati = sc.nextLine();
			System.out.println("Ezarri geltokiaren luzeera (Adb: -1.960650618338729):  ");
			longi = sc.nextLine();

			String sql = "INSERT INTO station "
					+ "(Name, Province, Town, Address, CoordenatesXETRS89, CoordenatesYETRS89, Latitude, Longitude) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

			PreparedStatement ps = c.konektatu().prepareStatement(sql);

			ps.setString(1, name);
			ps.setString(2, prov);
			ps.setString(3, town);
			ps.setString(4, addr);
			ps.setString(5, coorX);
			ps.setString(6, coorY);
			ps.setString(7, lati);
			ps.setString(8, longi);

			ResultSet rs = ps.executeQuery();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public static void update() {
		connection c = new connection();
		String name, prov, town, addr, coorX, coorY, lati, longi, oldname;
		Scanner sc = new Scanner(System.in);
		try {

			String sql = "UPDATE station SET Name=?, " + "Province=?, Town=?, Address=?, CoordenatesXETRS89=?, "
					+ "CoordenatesYETRS89=?, Latitude=?, Longitude=? WHERE Name=?";

			System.out.println("Sartu eguneratu nahi duzun geltokia: ");
			oldname = sc.nextLine();
			System.out.println("Ezarri geltokiaren izen berria (Maiuskuletan): ");
			name = sc.nextLine();
			System.out.println("Ezarri geltokiaren probintzia: ");
			prov = sc.nextLine();
			System.out.println("Ezarri geltokiaren herria: ");
			town = sc.nextLine();
			System.out.println("Ezarri geltokiaren helbidea: ");
			addr = sc.nextLine();
			System.out.println("Ezarri geltokiaren X koordenadak (Adb: 54263.4223): ");
			coorX = sc.nextLine();
			System.out.println("Ezarri geltokiaren Y koordenadak (Adb: 4539.792): ");
			coorY = sc.nextLine();
			System.out.println("Ezarri geltokiaren latitudea (Adb: 39.54931687): ");
			lati = sc.nextLine();
			System.out.println("Ezarri geltokiaren luzeera (Adb: -1.960650618338729):  ");
			longi = sc.nextLine();

			PreparedStatement ps = c.konektatu().prepareStatement(sql);

			ps.setString(9, oldname);
			ps.setString(1, name);
			ps.setString(2, prov);
			ps.setString(3, town);
			ps.setString(4, addr);
			ps.setString(5, coorX);
			ps.setString(6, coorY);
			ps.setString(7, lati);
			ps.setString(8, longi);

			ResultSet rs = ps.executeQuery();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}

	}

	public static void delete() {
		connection c = new connection();
		String oldname, name = "";
		Scanner sc = new Scanner(System.in);
		try {
			String sql = "DELETE FROM station WHERE Name=?";

			PreparedStatement ps = c.konektatu().prepareStatement(sql);

			System.out.println("Ezarri ezabatu nahi duzun geltoki izena: ");
			oldname = sc.nextLine();

			ps.setString(1, oldname);

			ResultSet rs = ps.executeQuery();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		System.out.println("ONDO EZABATUTA!!! ");
	}

	public static void probintziak() {
		connection c = new connection();
		String probintziak;
		Scanner sc = new Scanner(System.in);
		ArrayList<Station> list = new ArrayList<Station>();
		try {
			String sql = "SELECT * FROM station WHERE Province like ?";

			PreparedStatement ps = c.konektatu().prepareStatement(sql);
			
			System.out.println("Sartu geltokien probintzia erakusteko (Araba, Gipuzkoa edo Bizkaia): ");
			probintziak = sc.nextLine();
			
			ps.setString(1, "%" + probintziak + "%" );
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Station s = new Station();
				s.setName(rs.getString("Name"));
				s.setProvince(rs.getString("Province"));
				s.setTown(rs.getString("Town"));
				s.setAddress(rs.getString("Address"));
				s.setCoordenatesXETRS89(rs.getString("CoordenatesXETRS89"));
				s.setCoordenatesYETRS89(rs.getString("CoordenatesYETRS89"));
				s.setLatitude(rs.getString("Latitude"));
				s.setLongitude(rs.getString("Latitude"));
				list.add(s);
			}
			
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
