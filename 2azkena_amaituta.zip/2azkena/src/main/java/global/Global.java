/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package global;

import java.util.Scanner;

/**
 *
 * @author DM3-2-09
 */
public class Global {

	public static final String ZERBITZARIA = "localhost";
	public static final String DATUBASEA = "estaciones";
	
	public static final String csvFile = "estaciones.csv";
	public static final String xmlFile = "estaciones.xml";
	public static final String jsonFile = "estaciones.json";

	private static String erabiltzailea = "root";
	private static String pasahitza = "admin";

	public static String getErabiltzailea() {
		return erabiltzailea;
	}

	public static void setErabiltzailea(String erabiltzailea) {
		Global.erabiltzailea = erabiltzailea;
	}

	public static String getPasahitza() {
		return pasahitza;
	}

	public static void setPasahitza(String pasahitza) {
		Global.pasahitza = pasahitza;
	}

}
