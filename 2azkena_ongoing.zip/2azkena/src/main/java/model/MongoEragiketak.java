package model;

import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class MongoEragiketak {

	static CodecRegistry pojoCodecRegistry = fromRegistries(MongoClientSettings.getDefaultCodecRegistry(),
			fromProviders(PojoCodecProvider.builder().automatic(true).build()));
	static MongoClientSettings settings = MongoClientSettings.builder().codecRegistry(pojoCodecRegistry).build();
	static MongoClient mongoClient = MongoClients.create(settings);
	static MongoDatabase database = mongoClient.getDatabase("stations");
	static MongoCollection<Station> collection = database.getCollection("stations", Station.class);

	public static void main(String[] args) {
		readAll();

	}

	public static void readAll() {

		try (MongoCursor<Station> cur = collection.find().iterator()) {

			while (cur.hasNext()) {
				var station = cur.next();
				System.out.println("Name: " + station.getName() + " | Province: " + station.getProvince() + " | Town:"
						+ station.getTown() + " | Address: " + station.getAddress() + " | CoordenatesX: "
						+ station.getCoordenatesXETRS89() + "" + station.getCoordenatesYETRS89() + ""
						+ station.getLatitude() + "" + station.getLongitude());
			}
		}

	}
}
