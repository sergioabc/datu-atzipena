package model;

import test.connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MariaDBEragiketak {

	public static void main(String[] args) {
		
		read();
		
	}
	
	public static ArrayList<Station> read(){
		
		connection c = new connection();
		//c.konektatu();
		ArrayList<Station> list = new ArrayList<Station>();
		try {
		String sql = "SELECT * FROM station";
		PreparedStatement ps=c.konektatu().prepareStatement(sql);
		ResultSet rs= ps.executeQuery();
		while(rs.next()) {
			Station s = new Station();
			s.setName(rs.getString("Name"));
			s.setProvince(rs.getString("Province"));
			s.setTown(rs.getString("Town"));
			s.setAddress(rs.getString("Address"));
			s.setCoordenatesXETRS89(rs.getString("CoordenatesXETRS89"));
			s.setCoordenatesYETRS89(rs.getString("CoordenatesYETRS89"));
			s.setLatitude(rs.getString("Latitude"));
			s.setLongitude(rs.getString("Latitude"));
			list.add(s);
		}
		ps.close();
		ps=null;
		c.desconectar();
		
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		}
		
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		return list;
	}
}
