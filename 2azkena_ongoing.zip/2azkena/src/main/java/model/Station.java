package model;

import org.bson.types.ObjectId;

public class Station {

	public String Name;
	public String Province;
	public String Town;
	public String Address;
	public String CoordenatesXETRS89;
	public String CoordenatesYETRS89;
	public String Latitude;
	public String Longitude;

	public Station(String name, String province, String town, String address, String coordenatesXETRS89,
			String coordenatesYETRS89, String latitude, String longitude) {
		super();
		Name = name;
		Province = province;
		Town = town;
		Address = address;
		CoordenatesXETRS89 = coordenatesXETRS89;
		CoordenatesYETRS89 = coordenatesYETRS89;
		Latitude = latitude;
		Longitude = longitude;
	}

	public Station() {
		super();
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getProvince() {
		return Province;
	}

	public void setProvince(String province) {
		Province = province;
	}

	public String getTown() {
		return Town;
	}

	public void setTown(String town) {
		Town = town;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getCoordenatesXETRS89() {
		return CoordenatesXETRS89;
	}

	public void setCoordenatesXETRS89(String coordenatesXETRS89) {
		CoordenatesXETRS89 = coordenatesXETRS89;
	}

	public String getCoordenatesYETRS89() {
		return CoordenatesYETRS89;
	}

	public void setCoordenatesYETRS89(String coordenatesYETRS89) {
		CoordenatesYETRS89 = coordenatesYETRS89;
	}

	public String getLatitude() {
		return Latitude;
	}

	public void setLatitude(String latitude) {
		Latitude = latitude;
	}

	public String getLongitude() {
		return Longitude;
	}

	public void setLongitude(String longitude) {
		Longitude = longitude;
	}

	@Override
	public String toString() {
		return "station " + ", Name=" + Name + ", Province=" + Province + ", Town=" + Town + ", Address=" + Address
				+ ", CoordenatesXETRS89=" + CoordenatesXETRS89 + ", CoordenatesYETRS89=" + CoordenatesYETRS89
				+ ", Latitude=" + Latitude + ", Longitude=" + Longitude + "]";
	}

	public String toStringVacio() {
		return Name + ", " + Province + ", " + Town + ", " + Address + ", " + CoordenatesXETRS89 + ", "
				+ CoordenatesYETRS89 + ", " + Latitude + ", " + Longitude;
	}

}
