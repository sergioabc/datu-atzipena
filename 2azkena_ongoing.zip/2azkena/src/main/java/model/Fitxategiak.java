package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class Fitxategiak {

	static Document xmlDOM;

	public static void main(String[] args) {
		String csvFile = "estaciones.csv";
		String csvFileUPDATE = "estacionesEGUNERATUTA.csv";
		String xmlFile = "estaciones.xml";
		String jsonFile = "estaciones.json";

		// irakurricsv(csvFile);
		// idatzicsv(csvFile, csvFileOut);
		eguneratucsv(csvFile);
		// ezabatucsv();

		// irakurrixml(xmlFile);
		// irakurrijson(jsonFile);

	}

	public static void irakurricsv(String csvFile) {
		try (BufferedReader inputStream = new BufferedReader(new FileReader(csvFile))) {
			String l;
			String[] lerroa;
			while ((l = inputStream.readLine()) != null) {
				lerroa = l.split(",");

				System.out.println("Name: " + lerroa[0] + ", Province: " + lerroa[1] + ", Town: " + lerroa[2]
						+ ", Address: " + lerroa[3] + ", CoorX: " + lerroa[4] + ", CoorY: " + lerroa[5] + ", Latitude: "
						+ lerroa[6] + ", Longitude: " + lerroa[7]);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Error: " + e);
		} catch (IOException ex) {
			Logger.getLogger(Fitxategiak.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public static void idatzicsv(String csvFile, String csvFileOut) {
		String l, izena, probintzia, herria, helbidea, koordX, koordY, latitudea, luzera;
		String[] data = null;
		Scanner sc = new Scanner(System.in);
		try (BufferedReader inputStream = new BufferedReader(new FileReader(csvFile))) {
			BufferedWriter bw = null;

			String[] lerroa;
			while ((l = inputStream.readLine()) != null) {
				lerroa = l.split(",");
			}
			bw = new BufferedWriter(new FileWriter(new File(csvFile), true));
			System.out.println("Ezarri geltokiaren izena (Maiuskuletan): ");
			izena = sc.nextLine();
			System.out.println("Ezarri geltokiaren probintzia: ");
			probintzia = sc.nextLine();
			System.out.println("Ezarri geltokiaren herria: ");
			herria = sc.nextLine();
			System.out.println("Ezarri geltokiaren helbidea: ");
			helbidea = sc.nextLine();
			System.out.println("Ezarri geltokiaren X koordenadak (Adb: 54263.4223): ");
			koordX = sc.nextLine();
			System.out.println("Ezarri geltokiaren Y koordenadak (Adb: 4539.792): ");
			koordY = sc.nextLine();
			System.out.println("Ezarri geltokiaren latitudea (Adb: 39.54931687): ");
			latitudea = sc.nextLine();
			System.out.println("Ezarri geltokiaren luzeera (Adb: -1.960650618338729):  ");
			luzera = sc.nextLine();

			Station st = new Station(izena, probintzia, herria, helbidea, koordX, koordY, latitudea, luzera);
			bw.write("\n" + st.toStringVacio());
			bw.flush();
			bw.close();
			System.out.println("Datuak ondo gordeta!!!");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void eguneratucsv(String csvFile) {
		Scanner sc = new Scanner(System.in);
		String name, newname, newprovince, newtown, newaddress, newcoorX, newcoorY, newlatitude, newlongitude, r, r2,
				r3, csvFileEguneratuta = "temp.csv";
		try {
			File fitxategia = new File(csvFile);
			File fitxategiEguneratuta = new File(csvFileEguneratuta);

			BufferedReader br = new BufferedReader(new FileReader(fitxategia));

			System.out.println("Sartu aldatu nahi duzun geltokiaren izena: ");
			name = sc.nextLine();
			// LEHENGO, AUKERATUTAKO GELTOKIAREN DATUAK ERAKUTSIKO DUGU
			while ((r = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(r, ",");
				if (r.contains(name)) {
					System.out.println(st.nextToken() + ", " + st.nextToken() + ", " + st.nextToken() + ", "
							+ st.nextToken() + ", " + st.nextToken() + ", " + st.nextToken() + ", " + st.nextToken()
							+ ", " + st.nextToken());
				}
			}

			br.close();

			System.out.println("Sartu geltokiaren izen berria: ");
			newname = sc.nextLine();
			System.out.println("Sartu geltokiaren probintzia: ");
			newprovince = sc.nextLine();
			System.out.println("Sartu geltokiaren herria: ");
			newtown = sc.nextLine();
			System.out.println("Sartu geltokiaren helbidea: ");
			newaddress = sc.nextLine();
			System.out.println("Sartu geltokiaren X koordenadak: ");
			newcoorX = sc.nextLine();
			System.out.println("Sartu geltokiaren Y koordenadak: ");
			newcoorY = sc.nextLine();
			System.out.println("Sartu geltokiaren zabalera: ");
			newlatitude = sc.nextLine();
			System.out.println("Sartu geltokiaren altuera: ");
			newlongitude = sc.nextLine();

			BufferedReader br2 = new BufferedReader(new FileReader(fitxategia));
			BufferedWriter bw = new BufferedWriter(new FileWriter(fitxategiEguneratuta));
			// HEMEN, EGUNERATUTAKO DATUAK BESTE FITXATEGI BATEAN GORDETZEN DITU
			while ((r2 = br2.readLine()) != null) {

				if (r2.contains(name)) {
					bw.write(newname + ", " + newprovince + ", " + newtown + ", " + newaddress + ", " + newcoorX + ", "
							+ newcoorY + ", " + newlatitude + ", " + newlongitude);
				} else {
					bw.write(r2);
				}
				bw.flush();
				bw.newLine();
			}

			bw.close();
			br2.close();
			
			fitxategia.delete();
			File d = new File(csvFile);
			fitxategiEguneratuta.renameTo(d);
			System.out.println("Ondo eguneratuta!");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void ezabatucsv() {
		try /* (BufferedReader inputStream = new BufferedReader(new FileReader(csvFile))) */ {
			Scanner sc = new Scanner(System.in);
			String l, tempFile = "temp.csv", csvFile = "estaciones.csv", name;
			File newFile = new File(tempFile);
			File oldFile = new File(csvFile);
			boolean a = true;
			String[] lerroa;

			FileWriter fw = new FileWriter(tempFile, true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);

			FileReader fr = new FileReader(csvFile);
			BufferedReader br = new BufferedReader(fr);

			System.out.println("Sartu ezabatu nahi duzun geltoki izena: ");
			name = sc.nextLine();
			while ((l = br.readLine()) != null) {
				lerroa = l.split(",");

				/*
				 * if (lerroa.equals(lerroa[0])) { pw.println(l); }
				 */
				if (!(lerroa[0].equalsIgnoreCase(name))) {
					pw.println(l);
				}

			}

			pw.flush();
			pw.close();
			fr.close();
			br.close();
			bw.close();
			fw.close();

			oldFile.delete();
			File d = new File(csvFile);
			newFile.renameTo(d);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void irakurrixml(String xmlFile) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(xmlFile);

			NodeList stationList = doc.getElementsByTagName("station");

			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

			for (int i = 0; i < stationList.getLength(); i++) {
				Node n = stationList.item(i);
				System.out.println("Node name: " + n.getNodeName() + " " + (i + 1));
				if (n.getNodeType() == Node.ELEMENT_NODE) {
					Element name = (Element) n;
					System.out.println("Station id: " + name.getAttribute("id"));
					System.out.println("Name: " + name.getElementsByTagName("Name").item(0).getTextContent());
					System.out.println("Province: " + name.getElementsByTagName("Province").item(0).getTextContent());
					System.out.println("Town: " + name.getElementsByTagName("Town").item(0).getTextContent());
					System.out.println("Address: " + name.getElementsByTagName("Address").item(0).getTextContent());
					System.out.println("CoordenatesXETRS89: "
							+ name.getElementsByTagName("CoordenatesXETRS89").item(0).getTextContent());
					System.out.println("CoordenatesYETRS89: "
							+ name.getElementsByTagName("CoordenatesYETRS89").item(0).getTextContent());
					System.out.println("Latitude: " + name.getElementsByTagName("Latitude").item(0).getTextContent());
					System.out.println("Longitude: " + name.getElementsByTagName("Longitude").item(0).getTextContent());
					System.out.println("-------------------------------------------------------------");

				}
			}

		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}

	public static void idatzixml(String xmlFile) {
		DOMSource source = new DOMSource(xmlDOM);
	}

	public static void irakurrijson(String jsonFile) {
		JSONParser jsonP = new JSONParser();

		try (FileReader reader = new FileReader("estaciones.json")) {
			Object obj = jsonP.parse(reader);

			JSONArray stList = (JSONArray) obj;
			// System.out.println(stList);
			for (int i = 0; i < stList.size(); i++) {
				// System.out.println(stList.get(i));
				JSONObject stobj = (JSONObject) stList.get(i);

				String name = (String) stobj.get("Name");
				String province = (String) stobj.get("Province");
				String town = (String) stobj.get("Town");
				String address = (String) stobj.get("Address");
				String coorX = (String) stobj.get("CoordenatesXETRS89");
				String coorY = (String) stobj.get("CoordenatesYETRS89");
				String latitude = (String) stobj.get("Latitude");
				String longitude = (String) stobj.get("Longitude");

				System.out.println("Name: " + name + " | Province: " + province + " | Town: " + town + " | Address: "
						+ address + " | CoordenatesX: " + coorX + " | CoordenatesY: " + coorY + " | Latitude: "
						+ latitude + " | Longitude: " + longitude);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static Document domxml(String xmlFile) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new File(xmlFile));
			return document;

		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
